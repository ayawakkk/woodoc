package com.tianji.learning.mapper;

import com.tianji.learning.domain.po.NoteUser;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author 虎哥
 */
public interface NoteUserMapper extends BaseMapper<NoteUser> {

}
