package com.tianji.common.utils;

import cn.hutool.core.util.StrUtil;

/**
 * 字符串工具类,继承了{@link StrUtil}
 **/
public class StringUtils extends StrUtil {
}