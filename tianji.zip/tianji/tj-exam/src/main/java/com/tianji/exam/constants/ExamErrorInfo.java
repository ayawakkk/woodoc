package com.tianji.exam.constants;

public interface ExamErrorInfo {
    String QUESTION_NOT_EXISTS = "题目不存在";
}
