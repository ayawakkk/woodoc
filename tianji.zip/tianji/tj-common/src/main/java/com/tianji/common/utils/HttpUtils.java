package com.tianji.common.utils;

import cn.hutool.http.HttpUtil;

public class HttpUtils extends HttpUtil {
}
