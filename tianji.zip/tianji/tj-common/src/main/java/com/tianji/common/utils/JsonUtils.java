package com.tianji.common.utils;

import cn.hutool.json.JSONUtil;

public class JsonUtils extends JSONUtil {
}