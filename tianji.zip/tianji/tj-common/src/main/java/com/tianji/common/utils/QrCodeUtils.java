package com.tianji.common.utils;

import cn.hutool.extra.qrcode.QrCodeUtil;

/**
 * 二维码工具，想要使用此工具，项目中一定要引入com.google.zxing
 **/
public class QrCodeUtils extends QrCodeUtil {


}
