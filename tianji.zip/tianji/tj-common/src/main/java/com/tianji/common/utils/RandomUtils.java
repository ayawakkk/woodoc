package com.tianji.common.utils;

import cn.hutool.core.util.RandomUtil;

public class RandomUtils extends RandomUtil {
}
