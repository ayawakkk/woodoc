package com.hspedu.springboot.bean;

/**
 * @author 韩顺平
 * @version 1.0
 */
public class Cat {
}
