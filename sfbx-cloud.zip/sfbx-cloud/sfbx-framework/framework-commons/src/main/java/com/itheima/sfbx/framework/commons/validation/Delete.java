package com.itheima.sfbx.framework.commons.validation;

/**
 * @ClassName Delete.java
 * @Description validation的Update类型组
 */
public interface Delete {
}
