package com.tianji.api.constants;

public interface SmsConstants {
    String VERIFY_CODE_PARAM_NAME = "code";
}
