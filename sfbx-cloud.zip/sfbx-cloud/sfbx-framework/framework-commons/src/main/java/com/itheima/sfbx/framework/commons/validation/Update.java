package com.itheima.sfbx.framework.commons.validation;

/**
 * @ClassName Update.java
 * @Description validation的Update类型组
 */
public interface Update {
}
