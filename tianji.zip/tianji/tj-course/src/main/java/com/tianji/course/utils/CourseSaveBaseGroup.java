package com.tianji.course.utils;

/**
 * 用于校验课程分组的基本信息，
 * @ClassName CourseSaveBaseGroup
 * @Author wusongsong
 * @Date 2022/7/18 21:04
 * @Version
 **/
public interface CourseSaveBaseGroup {
}