package com.tianji.api.annotations;

public @interface EnableCategoryCache {
}
