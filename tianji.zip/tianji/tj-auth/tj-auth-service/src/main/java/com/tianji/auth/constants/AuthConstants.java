package com.tianji.auth.constants;

public abstract class AuthConstants {
    /*管理员的角色ID*/
    public static final Long ADMIN_ROLE_ID = 1L;
}
