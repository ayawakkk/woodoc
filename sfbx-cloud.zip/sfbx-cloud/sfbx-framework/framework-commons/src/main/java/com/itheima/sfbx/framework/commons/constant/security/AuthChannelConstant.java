package com.itheima.sfbx.framework.commons.constant.security;

/**
 * @ClassName AuthChannelCacheConstant.java
 * @Description
 */
public class AuthChannelConstant {

    //投保渠道
    public static final String CHANNEL_LABEL_INSURE = "INSURE";

    //公钥
    public static final String PUBLICKEY="publicKey";
}
