package com.hspedu.springboot.bean;

import org.springframework.stereotype.Repository;

/**
 * @author 韩顺平
 * @version 1.0
 */
@Repository
public class A {
}
