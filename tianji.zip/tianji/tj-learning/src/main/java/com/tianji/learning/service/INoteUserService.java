package com.tianji.learning.service;

import com.tianji.learning.domain.po.NoteUser;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 虎哥
 */
public interface INoteUserService extends IService<NoteUser> {

}
