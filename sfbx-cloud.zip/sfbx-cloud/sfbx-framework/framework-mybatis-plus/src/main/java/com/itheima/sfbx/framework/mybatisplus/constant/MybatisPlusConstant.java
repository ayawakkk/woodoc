
package com.itheima.sfbx.framework.mybatisplus.constant;


/**
 * @Description 静态变量
 */
public class MybatisPlusConstant {

    //企业编号
    public static final String COMPANY_NO ="company_no";

    //创建人
    public static final String CREATE_BY ="create_by";

    //部门编号
    public static final String DATA_DEPT_NO ="data_dept_no";

}
