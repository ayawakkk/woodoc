package com.tianji.learning.constants;

public interface LearningConstants {
    String POINTS_BOARD_TABLE_PREFIX = "points_board_";
}
