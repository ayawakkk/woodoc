package com.itheima.sfbx.framework.commons.constant.sick;

/**
 * SickConstant
 *
 * @author: wgl
 * @describe: 疾病常量类
 * @date: 2022/12/28 10:10
 */
public class SickConstant {

    public final static String SICK_TYPE = "DISEASE";
}
