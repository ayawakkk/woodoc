package com.itheima.sfbx.framework.commons.validation;

/**
 * @ClassName create.java
 * @Description validation的Create类型组
 */
public interface Create {
}
