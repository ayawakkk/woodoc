package com.tianji.common.utils;

import cn.hutool.core.util.BooleanUtil;

public class BooleanUtils extends BooleanUtil {
}
