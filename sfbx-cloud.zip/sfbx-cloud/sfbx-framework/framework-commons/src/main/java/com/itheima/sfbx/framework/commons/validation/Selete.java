package com.itheima.sfbx.framework.commons.validation;

/**
 * @ClassName Selete.java
 * @Description validation的Selete类型组
 */
public interface Selete {
}
