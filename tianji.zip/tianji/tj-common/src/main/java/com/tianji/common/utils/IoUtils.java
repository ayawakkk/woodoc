package com.tianji.common.utils;

import cn.hutool.core.io.IoUtil;

public class IoUtils extends IoUtil {
}
