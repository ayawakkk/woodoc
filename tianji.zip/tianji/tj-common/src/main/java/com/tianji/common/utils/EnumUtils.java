package com.tianji.common.utils;

import cn.hutool.core.util.EnumUtil;

public class EnumUtils extends EnumUtil {
}
